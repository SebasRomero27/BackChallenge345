package co.ciclo3.reto.reto.repository.crud;

import co.ciclo3.reto.reto.model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository <Client, Integer>{
}