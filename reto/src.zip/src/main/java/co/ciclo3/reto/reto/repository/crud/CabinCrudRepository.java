package co.ciclo3.reto.reto.repository.crud;

import co.ciclo3.reto.reto.model.Cabin;
import org.springframework.data.repository.CrudRepository;

public interface CabinCrudRepository extends CrudRepository <Cabin, Integer>{         
}
 