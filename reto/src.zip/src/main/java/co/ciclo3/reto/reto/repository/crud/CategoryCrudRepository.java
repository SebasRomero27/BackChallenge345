package co.ciclo3.reto.reto.repository.crud;

import co.ciclo3.reto.reto.model.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository <Category, Integer>{
}